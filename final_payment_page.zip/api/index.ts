import express from "express";
import session from "express-session";
import passport from "passport";
import { Pool } from "@neondatabase/serverless";
import pgSimple from "connect-pg-simple";
import { registerRoutes } from "../server/routes";
import { setupAuth } from "../server/replitAuth";

const app = express();

// Database session store
const pgSession = pgSimple(session);
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// CRITICAL: Register Stripe webhook BEFORE express.json()
app.post(
  '/api/stripe/webhook',
  express.raw({ type: 'application/json' }),
  async (req, res) => {
    const signature = req.headers['stripe-signature'];
    if (!signature) {
      return res.status(400).json({ error: 'Missing stripe-signature' });
    }
    try {
      const sig = Array.isArray(signature) ? signature[0] : signature;
      if (!Buffer.isBuffer(req.body)) {
        return res.status(500).json({ error: 'Webhook processing error' });
      }
      // Webhook handling will be in registerRoutes
      res.status(200).json({ received: true });
    } catch (error: any) {
      console.error('Webhook error:', error.message);
      res.status(400).json({ error: 'Webhook processing error' });
    }
  }
);

// Apply JSON middleware
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: false, limit: '50mb' }));

// Session configuration
app.use(session({
  store: new pgSession({
    pool,
    tableName: "sessions",
  }),
  secret: process.env.SESSION_SECRET || "fizz-secret-key",
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 30 * 24 * 60 * 60 * 1000,
    secure: process.env.NODE_ENV === "production",
    httpOnly: true,
    sameSite: "lax",
  },
}));

// Passport authentication
app.use(passport.initialize());
app.use(passport.session());

// Setup authentication and routes
registerRoutes(app);

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});

export default app;
